﻿namespace PROProtocol
{
    public enum StatType
    {
        Health,
        Attack,
        Defence,
        SpAttack,
        SpDefence,
        Speed
    }
}
