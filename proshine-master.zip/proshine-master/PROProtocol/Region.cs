﻿namespace PROProtocol
{
    public enum Region {
        Kanto = 1,
        Johto = 2,
        Hoenn = 3,
        Sinnoh = 4
    }
}
