﻿using System.Windows.Controls;

namespace PROShine
{
    public partial class ChatPanel : UserControl
    {
        public ChatPanel()
        {
            InitializeComponent();
        }
    }
}
