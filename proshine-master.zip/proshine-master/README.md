# PROShine

A free, open-source and advanced bot for Pokémon Revolution Online.

Community: https://proshine-bot.com/

Scripts: https://github.com/Silv3rPRO/proshine-scripts

## Libraries

* [MoonSharp](http://www.moonsharp.org/) - Lua interpreter
* [Json.NET](http://www.newtonsoft.com/json) - JSON framework

## Credits

* Main icon: [shiftercat on DeviantArt](https://shiftercat.deviantart.com/)
* Other icons: [Font Awesome](http://fontawesome.io/icons/)

## Contributors

https://github.com/Silv3rPRO/proshine/graphs/contributors
